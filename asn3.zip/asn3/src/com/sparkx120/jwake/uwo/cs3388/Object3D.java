package com.sparkx120.jwake.uwo.cs3388;

/**
 * Empty class to unify Objects (Will make certain methods required in the future)
 * @author James Wake
 * @version 0.0
 */
public class Object3D {
	
}

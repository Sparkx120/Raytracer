package com.sparkx120.jwake.uwo.cs3388;

public class RayData {
	//ArrayList ObjectIntersections
}
